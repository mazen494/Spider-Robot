from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('spider_robot_moveit_config'),
                'launch', 'demo.launch.py'
            )
        )
    )
    arduino_node = Node(
        package='arduino_interface',
        executable='serial_node',
        name='arduino_interface',
        output='screen'
    )
    controller_manager = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[
            {'robot_description': open(
                os.path.join(
                    get_package_share_directory('spider_robot_description'),
                    'urdf', 'spider_robot.urdf'
                )).read()},
            os.path.join(
                get_package_share_directory('spider_robot_control'),
                'config', 'ros2_controllers.yaml'
            )
        ],
        output='screen'
    )
    spawn_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_trajectory_controller', '--controller-manager', '/controller_manager'],
        output='screen'
    )
    return LaunchDescription([
        moveit_launch,
        arduino_node,
        controller_manager,
        spawn_controller
    ])
