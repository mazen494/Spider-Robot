from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, RegisterEventHandler, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    urdf_path = os.path.join(
        get_package_share_directory('spider_robot'),
        'urdf',
        'model.urdf'
    )

    return LaunchDescription([
        # Start Gazebo with empty world
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                os.path.join(
                    get_package_share_directory('gazebo_ros'),
                    'launch',
                    'gazebo.launch.py'
                )
            ])
        ),
        # Spawn the robot
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-file', urdf_path, '-entity', 'spider_robot'],
            output='screen'
        ),
        # Start the control node with the URDF and YAML
        Node(
            package='controller_manager',
            executable='ros2_control_node',
            parameters=[
                urdf_path,
                os.path.join(
                    get_package_share_directory('spider_robot'),
                    'config',
                    'spider_controllers.yaml'
                )
            ],
            output='screen'
        ),
        # Add a delay before spawning controllers
        RegisterEventHandler(
            event_handler=TimerAction(
                actions=[
                    Node(
                        package='controller_manager',
                        executable='spawner',
                        arguments=['joint_state_broadcaster'],
                        output='screen'
                    ),
                    Node(
                        package='controller_manager',
                        executable='spawner',
                        arguments=['leg1_joint_controller'],
                        output='screen'
                    ),
                    Node(
                        package='controller_manager',
                        executable='spawner',
                        arguments=['leg2_joint_controller'],
                        output='screen'
                    ),
                    Node(
                        package='controller_manager',
                        executable='spawner',
                        arguments=['leg3_joint_controller'],
                        output='screen'
                    ),
                    Node(
                        package='controller_manager',
                        executable='spawner',
                        arguments=['leg4_joint_controller'],
                        output='screen'
                    ),
                ],
                period=5.0  # Delay of 5 seconds
            )
        )
    ])
