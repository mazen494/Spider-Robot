import rclpy
from rclpy.node import Node
from moveit_msgs.msg import DisplayTrajectory
import serial
import time


class ServoPublisher(Node):
    def _init_(self):
        super()._init_('servo_publisher')
        self.ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)

        self.subscription = self.create_subscription(
            DisplayTrajectory,
            '/display_planned_path',
            self.trajectory_callback,
            10
        )

        self.joint_order = [
            'Link1_j', 'Leg1_j', 'Link2_j',     # Front Right
            'Link3_j', 'Leg3_j', 'Link4_j',        # Front Left
                    # Back Left
        ]

        self.get_logger().info('ServoPublisher node started and listening to /display_planned_path')

    def trajectory_callback(self, msg):
        if not msg.trajectory:
            self.get_logger().warn("Empty trajectory received.")
            return

        joint_trajectory = msg.trajectory[0].joint_trajectory

        for point in joint_trajectory.points:
            angles = []
            for joint_name in self.joint_order:
                if joint_name in joint_trajectory.joint_names:
                    idx = joint_trajectory.joint_names.index(joint_name)
                    angle_rad = point.positions[idx]
                    angle_deg = int(-angle_rad * 180.0 / 3.14159)  # Invert angle for hardware
                    angles.append(str(angle_deg))
                else:
                    angles.append('0')

            data = ','.join(angles) + '\n'
            self.ser.write(data.encode())
            self.get_logger().info(f"Sent: {data.strip()}")
            time.sleep(0.1)  # Small delay between each step

def main(args=None):
    rclpy.init(args=args)
    node = ServoPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '_main_':
    main()
