import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from std_msgs.msg import String
import serial
import serial.tools.list_ports
import time
import math

class ArduinoInterface(Node):
    def __init__(self):
        super().__init__('arduino_interface')
        port = None
        for p in serial.tools.list_ports.comports():
            if 'Arduino' in p.description or 'CH340' in p.description:
                port = p.device
                break
        if not port:
            self.get_logger().error('No Arduino found')
            raise RuntimeError('No Arduino found')
        self.get_logger().info(f'Using serial port: {port}')
        self.serial_port = serial.Serial(port, 9600, timeout=1)
        time.sleep(3)
        self.trajectory_sub = self.create_subscription(
            JointTrajectory,
            '/joint_trajectory',
            self.trajectory_callback,
            10)
        self.status_publisher = self.create_publisher(String, '/arduino_status', 10)
        self.timer = self.create_timer(0.1, self.read_arduino)

    def trajectory_callback(self, msg):
        if msg.points:
            point = msg.points[-1]
            for joint_name, position in zip(msg.joint_names, point.positions):
                angle = int(math.degrees(position))
                angle = max(0, min(180, angle))
                command = f"JOINT:{joint_name}:{angle}\n"
                self.serial_port.write(command.encode())
                self.get_logger().info(f'Sent to Arduino: {command.strip()}')

    def read_arduino(self):
        if self.serial_port.in_waiting > 0:
            data = self.serial_port.readline().decode().strip()
            if data:
                msg = String()
                msg.data = data
                self.status_publisher.publish(msg)
                self.get_logger().info(f'Received from Arduino: {data}')

def main(args=None):
    rclpy.init(args=args)
    try:
        node = ArduinoInterface()
        rclpy.spin(node)
    except Exception as e:
        print(f'Error: {e}')
    finally:
        if 'node' in locals():
            node.serial_port.close()
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
